-- Production schema: PostgreSQL 16 + PostGIS 3.4+.
-- Precise contributor positions stay restricted; public queries use generalized points only.
CREATE EXTENSION IF NOT EXISTS postgis;
CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TYPE report_state AS ENUM (
  'QUEUED_FOR_SERVER_ANALYSIS',
  'AUTO_ACCEPTED_PENDING_REVIEW',
  'NOT_ELIGIBLE',
  'HUMAN_APPROVED',
  'HUMAN_REJECTED'
);

CREATE TABLE river_segments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  source_name text NOT NULL,
  source_feature_id text NOT NULL,
  river_name text,
  geom geometry(LineString, 4326) NOT NULL,
  UNIQUE (source_name, source_feature_id)
);
CREATE INDEX river_segments_geom_gix ON river_segments USING gist (geom);

CREATE TABLE reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  reporter_hash bytea NOT NULL, -- one-way HMAC(account ID); never store an email here
  state report_state NOT NULL DEFAULT 'QUEUED_FOR_SERVER_ANALYSIS',
  uploaded_object_key text NOT NULL UNIQUE,
  sha256 char(64) NOT NULL,
  perceptual_hash char(16),
  captured_at timestamptz,
  received_at timestamptz NOT NULL DEFAULT now(),
  location geometry(Point, 4326) NOT NULL, -- restricted field; protected by RLS
  gps_accuracy_m real NOT NULL CHECK (gps_accuracy_m >= 0),
  nearest_river_segment_id uuid REFERENCES river_segments(id),
  river_distance_m real NOT NULL CHECK (river_distance_m >= 0),
  image_quality real CHECK (image_quality BETWEEN 0 AND 1),
  visible_litter_severity smallint CHECK (visible_litter_severity BETWEEN 0 AND 100),
  evidence_reliability smallint CHECK (evidence_reliability BETWEEN 0 AND 100),
  priority_score smallint CHECK (priority_score BETWEEN 0 AND 100),
  duplicate_of uuid REFERENCES reports(id),
  score_policy_version text,
  CONSTRAINT approved_requires_score CHECK (
    state NOT IN ('AUTO_ACCEPTED_PENDING_REVIEW', 'HUMAN_APPROVED')
    OR priority_score IS NOT NULL
  )
);
CREATE INDEX reports_location_gix ON reports USING gist (location);
CREATE INDEX reports_state_received_idx ON reports (state, received_at DESC);
CREATE INDEX reports_sha256_idx ON reports (sha256);
CREATE INDEX reports_perceptual_hash_idx ON reports (perceptual_hash) WHERE perceptual_hash IS NOT NULL;

CREATE TABLE model_runs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  report_id uuid NOT NULL UNIQUE REFERENCES reports(id) ON DELETE CASCADE,
  model_name text NOT NULL,
  model_version text NOT NULL,
  calibration_version text NOT NULL,
  input_sha256 char(64) NOT NULL,
  inference_ms integer CHECK (inference_ms >= 0),
  created_at timestamptz NOT NULL DEFAULT now(),
  raw_response jsonb NOT NULL
);

CREATE TABLE detections (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  model_run_id uuid NOT NULL REFERENCES model_runs(id) ON DELETE CASCADE,
  class_name text NOT NULL CHECK (class_name IN (
    'plastic_bottle', 'plastic_bag', 'food_wrapper', 'can',
    'styrofoam', 'fishing_net', 'other_litter'
  )),
  calibrated_confidence real NOT NULL CHECK (calibrated_confidence BETWEEN 0 AND 1),
  bbox jsonb NOT NULL, -- normalized xmin/ymin/width/height
  area_fraction real NOT NULL CHECK (area_fraction > 0 AND area_fraction <= 1),
  accepted_by_policy boolean NOT NULL
);
CREATE INDEX detections_run_idx ON detections (model_run_id);

CREATE TABLE review_decisions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  report_id uuid NOT NULL REFERENCES reports(id) ON DELETE CASCADE,
  reviewer_hash bytea NOT NULL,
  decision text NOT NULL CHECK (decision IN ('APPROVED', 'REJECTED', 'NEEDS_CONTEXT')),
  reason_code text NOT NULL,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX review_decisions_report_idx ON review_decisions (report_id, created_at DESC);

CREATE TABLE training_labels (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  report_id uuid NOT NULL REFERENCES reports(id) ON DELETE CASCADE,
  annotation_version text NOT NULL,
  annotation jsonb NOT NULL,
  annotator_hash bytea NOT NULL,
  reviewed_by_hash bytea,
  status text NOT NULL CHECK (status IN ('DRAFT', 'ADJUDICATED', 'EXCLUDED')),
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Never mix image-derived litter scores with physical measurements.
CREATE TABLE water_measurements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  source_name text NOT NULL,
  source_record_id text NOT NULL,
  collected_at timestamptz NOT NULL,
  location geometry(Point, 4326) NOT NULL,
  parameter_code text NOT NULL, -- e.g. pH, dissolved oxygen, E. coli
  value numeric NOT NULL,
  unit text NOT NULL,
  method text,
  quality_flag text,
  raw jsonb NOT NULL,
  UNIQUE (source_name, source_record_id, parameter_code)
);
CREATE INDEX water_measurements_location_gix ON water_measurements USING gist (location);
CREATE INDEX water_measurements_time_idx ON water_measurements (collected_at DESC);

-- Worker-only river matching query; do not accept river_distance_m from a browser.
-- SELECT id, river_name,
--        ST_Distance(geom::geography, ST_SetSRID(ST_MakePoint($1, $2), 4326)::geography) AS distance_m
-- FROM river_segments
-- ORDER BY geom <-> ST_SetSRID(ST_MakePoint($1, $2), 4326)
-- LIMIT 1;

-- Enable RLS in production and grant public clients SELECT only to a view that omits
-- reports.location, uploaded_object_key, hashes, and raw inference data.
ALTER TABLE reports ENABLE ROW LEVEL SECURITY;
ALTER TABLE model_runs ENABLE ROW LEVEL SECURITY;
ALTER TABLE detections ENABLE ROW LEVEL SECURITY;
ALTER TABLE review_decisions ENABLE ROW LEVEL SECURITY;
ALTER TABLE training_labels ENABLE ROW LEVEL SECURITY;
