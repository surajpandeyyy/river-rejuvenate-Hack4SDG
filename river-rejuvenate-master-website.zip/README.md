# AquaNexus + River Rejuvenate — Master Website

This integration combines the AquaNexus river archive homepage and the River Rejuvenate community gamification dashboard, with a shared Node.js HTTP server and the supplied hotspot API modules.

## Run locally

1. Install Node.js 18 or newer.
2. Open a terminal in this folder.
3. Run `npm start`.
4. Open `http://localhost:3000` for AquaNexus or `http://localhost:3000/gamification.html` for the impact dashboard.
5. Check `http://localhost:3000/health` to verify the API server.

No npm packages are required for the current server. The AquaNexus map uses Leaflet from a CDN, so map tiles/library features need an internet connection.

## Included

- `public/index.html` — AquaNexus river archive
- `public/gamification.html` — River Rejuvenate gamification dashboard
- `backend/server.js` — static website server and hotspot API
- `backend/store.js`, `backend/scoring.js` — in-memory demo report/scoring logic
- `backend/mapbox-hotspots.js` — optional Mapbox GL hotspot layer helper
- `database/schema.sql` — PostgreSQL + PostGIS production schema reference

## Important limitations before production

- The API currently uses in-memory storage; reports disappear when the server restarts. It is a reference/demo implementation, not a production database integration.
- `database/schema.sql` is a PostgreSQL/PostGIS schema, but the API has not yet been wired to it. Configure a database adapter and migrations before relying on persistent reports.
- Replace the demo worker secret, add real staff authentication/authorization, configure restrictive CORS, and review upload/storage handling before production.
- The gamification dashboard's demo data is stored in browser local storage and is separate from the hotspot API. Do not treat its leaderboard or demo contributions as verified real-world evidence.
- Public hotspot coordinates are generalized by the scoring/store logic; never expose precise contributor locations publicly.

## Database setup

`database/schema.sql` expects PostgreSQL with PostGIS and pgcrypto available. Review and run it only against a development database first. The included API does not yet read/write this schema.
