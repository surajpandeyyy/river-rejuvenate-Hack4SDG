/**
 * Scores VISIBLE LITTER PRIORITY, not water chemistry.
 * Detection confidence must already be calibrated for the supplied model version.
 */
export const CLASS_POLICY = Object.freeze({
  plastic_bottle: { minConfidence: 0.76, severity: 1.00 },
  plastic_bag: { minConfidence: 0.78, severity: 1.15 },
  food_wrapper: { minConfidence: 0.74, severity: 0.70 },
  can: { minConfidence: 0.77, severity: 0.75 },
  styrofoam: { minConfidence: 0.80, severity: 1.05 },
  fishing_net: { minConfidence: 0.82, severity: 1.30 },
  other_litter: { minConfidence: 0.84, severity: 0.50 }
});

export const POLICY_VERSION = "litter-priority-v1";
export const MAX_GPS_ACCURACY_METERS = 50;
export const MAX_RIVER_DISTANCE_METERS = 200;
export const MIN_IMAGE_QUALITY = 0.60;

export function clamp(value, min = 0, max = 1) {
  return Math.min(max, Math.max(min, value));
}

export function isFiniteNumber(value) {
  return typeof value === "number" && Number.isFinite(value);
}

export function validateLocation(location) {
  if (!location || !isFiniteNumber(location.latitude) || !isFiniteNumber(location.longitude)) {
    return { ok: false, reason: "latitude and longitude are required" };
  }
  if (Math.abs(location.latitude) > 90 || Math.abs(location.longitude) > 180) {
    return { ok: false, reason: "coordinates are outside the valid range" };
  }
  if (!isFiniteNumber(location.accuracyMeters) || location.accuracyMeters < 0) {
    return { ok: false, reason: "a non-negative GPS accuracy in metres is required" };
  }
  if (!isFiniteNumber(location.riverDistanceMeters) || location.riverDistanceMeters < 0) {
    return { ok: false, reason: "a server-derived river distance is required" };
  }
  return { ok: true };
}

/** Great-circle distance, accurate for the report-deduplication radius. */
export function haversineMeters(a, b) {
  const radians = Math.PI / 180;
  const lat1 = a.latitude * radians;
  const lat2 = b.latitude * radians;
  const dLat = (b.latitude - a.latitude) * radians;
  const dLng = (b.longitude - a.longitude) * radians;
  const h = Math.sin(dLat / 2) ** 2
    + Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLng / 2) ** 2;
  return 6371008.8 * 2 * Math.atan2(Math.sqrt(h), Math.sqrt(1 - h));
}

export function hammingDistanceHex(left, right) {
  if (typeof left !== "string" || typeof right !== "string" || left.length !== right.length) return Infinity;
  let distance = 0;
  for (let index = 0; index < left.length; index += 1) {
    const xor = Number.parseInt(left[index], 16) ^ Number.parseInt(right[index], 16);
    if (Number.isNaN(xor)) return Infinity;
    distance += xor.toString(2).split("1").length - 1;
  }
  return distance;
}

function acceptedDetections(detections) {
  return detections.filter((detection) => {
    const policy = CLASS_POLICY[detection.className];
    return policy && isFiniteNumber(detection.confidence) && detection.confidence >= policy.minConfidence;
  });
}

function detectionContribution(detection) {
  const policy = CLASS_POLICY[detection.className];
  // areaFraction is the fraction of image covered by the object. The square root
  // limits the effect of a single close-up object.
  const area = clamp(isFiniteNumber(detection.areaFraction) ? detection.areaFraction : 0.02, 0.002, 0.60);
  const sizeWeight = 0.55 + 0.45 * Math.sqrt(area / 0.60);
  const aboveThreshold = (detection.confidence - policy.minConfidence) / (1 - policy.minConfidence);
  const confidenceWeight = 0.65 + 0.35 * clamp(aboveThreshold);
  return policy.severity * sizeWeight * confidenceWeight;
}

export function scoreReport({ location, imageQuality, detections, duplicate = false }) {
  const locationCheck = validateLocation(location);
  const quality = clamp(imageQuality?.score ?? 0);
  const validDetections = acceptedDetections(Array.isArray(detections) ? detections : []);
  const modelEvidence = validDetections.reduce((sum, detection) => sum + detectionContribution(detection), 0);
  const visibleLitterSeverity = Math.round(100 * (1 - Math.exp(-modelEvidence / 3.5)));
  const locationReliability = locationCheck.ok
    ? clamp((1 - location.accuracyMeters / 100) * (1 - location.riverDistanceMeters / 400))
    : 0;
  const modelReliability = validDetections.length === 0
    ? 0
    : validDetections.reduce((sum, detection) => sum + detection.confidence, 0) / validDetections.length;
  const evidenceReliability = Math.round(100 * Math.min(quality, locationReliability, modelReliability));
  const qualityGate = {
    goodImage: quality >= MIN_IMAGE_QUALITY,
    accurateLocation: locationCheck.ok && location.accuracyMeters <= MAX_GPS_ACCURACY_METERS,
    nearRiver: locationCheck.ok && location.riverDistanceMeters <= MAX_RIVER_DISTANCE_METERS,
    litterDetected: validDetections.length > 0,
    notDuplicate: !duplicate
  };
  const publishableEvidence = locationCheck.ok && Object.values(qualityGate).every(Boolean);
  const priorityScore = publishableEvidence
    ? Math.round(visibleLitterSeverity * (0.45 + 0.55 * evidenceReliability / 100))
    : 0;

  return {
    policyVersion: POLICY_VERSION,
    visibleLitterSeverity,
    evidenceReliability,
    priorityScore,
    acceptedDetections: validDetections,
    qualityGate,
    publishableEvidence,
    rejectionReason: locationCheck.ok ? null : locationCheck.reason
  };
}

export function timeDecay(createdAt, now = new Date(), halfLifeDays = 21) {
  const ageDays = Math.max(0, (now.getTime() - new Date(createdAt).getTime()) / 86400000);
  return 0.5 ** (ageDays / halfLifeDays);
}

export function publicCoordinate(value, precision = 0.002) {
  return Math.round(value / precision) * precision;
}
