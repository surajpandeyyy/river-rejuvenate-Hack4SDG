import { createHash, randomUUID } from "node:crypto";
import { haversineMeters, hammingDistanceHex, publicCoordinate, scoreReport, timeDecay } from "./scoring.js";

const HOTSPOT_RADIUS_METERS = 250;
const REPORTER_WINDOW_MS = 12 * 60 * 60 * 1000;

function assertText(value, field) {
  if (typeof value !== "string" || value.trim().length === 0 || value.length > 300) {
    throw new Error(field + " must be a non-empty string shorter than 300 characters");
  }
}

function stableReporterId(input) {
  assertText(input, "reporterId");
  // Keep an opaque account identifier, never an email or raw device fingerprint.
  return createHash("sha256").update(input).digest("hex");
}

export class MemoryHotspotStore {
  constructor() {
    this.reports = [];
  }

  createReport(payload) {
    assertText(payload?.photo?.objectKey, "photo.objectKey");
    assertText(payload?.photo?.sha256, "photo.sha256");
    const report = {
      id: randomUUID(),
      reporterId: stableReporterId(payload.reporterId),
      photo: {
        objectKey: payload.photo.objectKey,
        sha256: payload.photo.sha256,
        perceptualHash: payload.photo.perceptualHash ?? null
      },
      location: payload.location,
      clientCapturedAt: payload.clientCapturedAt ?? null,
      createdAt: new Date().toISOString(),
      state: "QUEUED_FOR_SERVER_ANALYSIS",
      review: null,
      scoring: null,
      modelRun: null
    };
    this.reports.push(report);
    return report;
  }

  findReport(id) {
    return this.reports.find((report) => report.id === id);
  }

  findDuplicate(report) {
    const timestamp = new Date(report.createdAt).getTime();
    return this.reports.find((other) => {
      if (other.id === report.id || !other.scoring) return false;
      const nearby = haversineMeters(report.location, other.location) <= 35;
      const closeInTime = Math.abs(timestamp - new Date(other.createdAt).getTime()) <= REPORTER_WINDOW_MS;
      const sameReporter = report.reporterId === other.reporterId;
      const sameImage = report.photo.sha256 === other.photo.sha256;
      const visuallySame = report.photo.perceptualHash && other.photo.perceptualHash
        && hammingDistanceHex(report.photo.perceptualHash, other.photo.perceptualHash) <= 6;
      return sameImage || (nearby && closeInTime && (sameReporter || visuallySame));
    });
  }

  attachInference(id, payload) {
    const report = this.findReport(id);
    if (!report) throw new Error("report not found");
    if (report.state !== "QUEUED_FOR_SERVER_ANALYSIS") throw new Error("inference may only be attached once");
    assertText(payload?.modelRun?.modelVersion, "modelRun.modelVersion");
    assertText(payload?.modelRun?.calibrationVersion, "modelRun.calibrationVersion");
    if (!Array.isArray(payload.detections)) throw new Error("detections must be an array");
    if (typeof payload?.imageQuality?.score !== "number") throw new Error("imageQuality.score is required");

    report.modelRun = {
      modelVersion: payload.modelRun.modelVersion,
      calibrationVersion: payload.modelRun.calibrationVersion,
      inferenceMs: payload.modelRun.inferenceMs ?? null
    };
    report.imageQuality = payload.imageQuality;
    report.detections = payload.detections;
    const duplicate = this.findDuplicate(report);
    report.scoring = scoreReport({
      location: report.location,
      imageQuality: report.imageQuality,
      detections: report.detections,
      duplicate: Boolean(duplicate)
    });
    report.duplicateOf = duplicate?.id ?? null;
    report.state = report.scoring.publishableEvidence ? "AUTO_ACCEPTED_PENDING_REVIEW" : "NOT_ELIGIBLE";
    return report;
  }

  reviewReport(id, decision, reviewerId) {
    const report = this.findReport(id);
    if (!report) throw new Error("report not found");
    if (!["APPROVED", "REJECTED"].includes(decision)) throw new Error("decision must be APPROVED or REJECTED");
    assertText(reviewerId, "reviewerId");
    report.review = { decision, reviewerId: stableReporterId(reviewerId), reviewedAt: new Date().toISOString() };
    report.state = decision === "APPROVED" ? "HUMAN_APPROVED" : "HUMAN_REJECTED";
    return report;
  }

  hotspotFeatures(now = new Date(), { includeUnconfirmed = false } = {}) {
    const candidates = this.reports.filter((report) => report.scoring?.publishableEvidence && report.state !== "HUMAN_REJECTED");
    const unassigned = [...candidates];
    const clusters = [];
    while (unassigned.length > 0) {
      const cluster = { reports: [unassigned.shift()] };
      let expanded = true;
      while (expanded) {
        expanded = false;
        for (let index = unassigned.length - 1; index >= 0; index -= 1) {
          if (cluster.reports.some((member) => haversineMeters(member.location, unassigned[index].location) <= HOTSPOT_RADIUS_METERS)) {
            cluster.reports.push(unassigned.splice(index, 1)[0]);
            expanded = true;
          }
        }
      }
      clusters.push(cluster);
    }
    const features = clusters.map((cluster) => this.#toFeature(cluster, now));
    return {
      type: "FeatureCollection",
      features: includeUnconfirmed ? features : features.filter((feature) => feature.properties.status !== "unconfirmed")
    };
  }

  #toFeature(cluster, now) {
    const contributors = new Set(cluster.reports.map((report) => report.reporterId));
    const approved = cluster.reports.filter((report) => report.state === "HUMAN_APPROVED").length;
    const seenReporterDays = new Set();
    let decayedPriority = 0;
    for (const report of cluster.reports) {
      const day = report.createdAt.slice(0, 10);
      const capKey = report.reporterId + ":" + day;
      if (seenReporterDays.has(capKey)) continue; // one person cannot inflate a cell in one day
      seenReporterDays.add(capKey);
      decayedPriority += report.scoring.priorityScore * timeDecay(report.createdAt, now);
    }
    const independentReports = contributors.size;
    const publicStatus = independentReports >= 3 || approved >= 1
      ? (decayedPriority >= 130 ? "critical" : "confirmed")
      : independentReports >= 2 ? "emerging" : "unconfirmed";
    const latitude = cluster.reports.reduce((sum, report) => sum + report.location.latitude, 0) / cluster.reports.length;
    const longitude = cluster.reports.reduce((sum, report) => sum + report.location.longitude, 0) / cluster.reports.length;
    return {
      type: "Feature",
      geometry: { type: "Point", coordinates: [publicCoordinate(longitude), publicCoordinate(latitude)] },
      properties: {
        status: publicStatus,
        priorityScore: Math.min(100, Math.round(decayedPriority)),
        independentReporters: independentReports,
        acceptedReports: cluster.reports.length,
        humanApprovedReports: approved,
        lastObservedAt: cluster.reports.map((report) => report.createdAt).sort().at(-1),
        methodology: "visible-litter-priority-v1"
      }
    };
  }
}
