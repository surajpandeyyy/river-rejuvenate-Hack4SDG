import http from "node:http";
import { URL } from "node:url";
import { readFile } from "node:fs/promises";
import { extname, resolve, sep } from "node:path";
import { fileURLToPath } from "node:url";
import { MemoryHotspotStore } from "./store.js";

const ROOT = resolve(fileURLToPath(new URL("../public/", import.meta.url)));
const JSON_LIMIT_BYTES = 1_000_000;
const MIME = { ".html":"text/html; charset=utf-8", ".css":"text/css; charset=utf-8", ".js":"text/javascript; charset=utf-8", ".json":"application/json; charset=utf-8", ".svg":"image/svg+xml", ".png":"image/png", ".jpg":"image/jpeg", ".jpeg":"image/jpeg", ".webp":"image/webp", ".ico":"image/x-icon" };
function send(response, status, body) {
  response.writeHead(status, { "content-type":"application/json; charset=utf-8", "access-control-allow-origin":"*", "access-control-allow-headers":"content-type,x-worker-secret,x-reviewer-id", "access-control-allow-methods":"GET,POST,OPTIONS" });
  response.end(JSON.stringify(body));
}
function publicReport(report) { return { id:report.id, state:report.state, createdAt:report.createdAt, duplicateOf:report.duplicateOf ?? null, modelRun:report.modelRun, scoring:report.scoring }; }
async function readJson(request) {
  let body=""; for await (const chunk of request) { body += chunk; if (Buffer.byteLength(body)>JSON_LIMIT_BYTES) throw new Error("request body is too large"); }
  if (!body) return {}; try { return JSON.parse(body); } catch { throw new Error("request body must be valid JSON"); }
}
async function serveStatic(urlPath, response) {
  let pathname = decodeURIComponent(urlPath);
  if (pathname === "/") pathname = "/index.html";
  const file = resolve(ROOT, "." + pathname);
  if (file !== ROOT && !file.startsWith(ROOT + sep)) return false;
  try { const data = await readFile(file); response.writeHead(200, {"content-type":MIME[extname(file).toLowerCase()] || "application/octet-stream", "x-content-type-options":"nosniff"}); response.end(data); return true; }
  catch { return false; }
}
export function createApi({ store = new MemoryHotspotStore(), workerSecret = process.env.WORKER_SECRET || "change-me-in-production" } = {}) {
  return http.createServer(async (request, response) => {
    if (request.method === "OPTIONS") { response.writeHead(204, {"access-control-allow-origin":"*","access-control-allow-headers":"content-type,x-worker-secret,x-reviewer-id","access-control-allow-methods":"GET,POST,OPTIONS"}); return response.end(); }
    const url = new URL(request.url, "http://localhost");
    try {
      if (request.method === "GET" && url.pathname === "/health") return send(response, 200, {ok:true,service:"river-rejuvenate-master-website",storage:"memory-demo-only"});
      if (request.method === "POST" && url.pathname === "/v1/reports") { const report=store.createReport(await readJson(request)); return send(response,202,{report:publicReport(report),next:"A trusted server worker must validate the uploaded image and attach inference results."}); }
      const inferenceMatch=url.pathname.match(/^\/internal\/reports\/([^/]+)\/inference$/);
      if (request.method === "POST" && inferenceMatch) { if(request.headers["x-worker-secret"]!==workerSecret)return send(response,401,{error:"worker authentication failed"}); const report=store.attachInference(inferenceMatch[1],await readJson(request)); return send(response,200,{report:publicReport(report)}); }
      const reviewMatch=url.pathname.match(/^\/v1\/reports\/([^/]+)\/review$/);
      if(request.method==="POST"&&reviewMatch){const reviewerId=request.headers["x-reviewer-id"];const report=store.reviewReport(reviewMatch[1],(await readJson(request)).decision,reviewerId);return send(response,200,{report:publicReport(report)});}
      const reportMatch=url.pathname.match(/^\/v1\/reports\/([^/]+)$/);
      if(request.method==="GET"&&reportMatch){const report=store.findReport(reportMatch[1]);return report?send(response,200,{report:publicReport(report)}):send(response,404,{error:"report not found"});}
      if(request.method==="GET"&&url.pathname==="/v1/hotspots")return send(response,200,store.hotspotFeatures());
      if(request.method==="GET" && await serveStatic(url.pathname,response)) return;
      return send(response,404,{error:"not found"});
    } catch(error) { return send(response,400,{error:error instanceof Error?error.message:"bad request"}); }
  });
}
if (process.argv[1] && import.meta.url === new URL(process.argv[1], "file:").href) {
  const port=Number(process.env.PORT||3000);
  createApi().listen(port,()=>console.log(`Master website running at http://localhost:${port}`));
}
