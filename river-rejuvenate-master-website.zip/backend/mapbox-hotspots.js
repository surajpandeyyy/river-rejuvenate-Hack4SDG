// Mapbox GL JS integration. Use this only with server-generated GeoJSON from /v1/hotspots.
// This map displays priority evidence, not a claim that the water is chemically unsafe.
export function addRiverHotspots(map, apiBaseUrl) {
  map.addSource("river-hotspots", { type: "geojson", data: { type: "FeatureCollection", features: [] } });

  map.addLayer({
    id: "river-hotspots-heat",
    type: "heatmap",
    source: "river-hotspots",
    maxzoom: 11,
    paint: {
      "heatmap-weight": ["interpolate", ["linear"], ["get", "priorityScore"], 0, 0, 100, 1],
      "heatmap-intensity": ["interpolate", ["linear"], ["zoom"], 3, 0.6, 10, 1.8],
      "heatmap-radius": ["interpolate", ["linear"], ["zoom"], 3, 12, 10, 32],
      "heatmap-color": [
        "interpolate", ["linear"], ["heatmap-density"],
        0, "rgba(0,0,0,0)",
        0.25, "#f9e35d",
        0.55, "#f39237",
        0.80, "#e4572e",
        1, "#9c1c1c"
      ],
      "heatmap-opacity": ["interpolate", ["linear"], ["zoom"], 8, 1, 11, 0]
    }
  });

  map.addLayer({
    id: "river-hotspots-points",
    type: "circle",
    source: "river-hotspots",
    minzoom: 8,
    paint: {
      "circle-radius": ["interpolate", ["linear"], ["get", "priorityScore"], 0, 5, 100, 18],
      "circle-color": [
        "match", ["get", "status"],
        "critical", "#9c1c1c",
        "confirmed", "#e4572e",
        "emerging", "#f39237",
        "#f9e35d"
      ],
      "circle-opacity": ["match", ["get", "status"], "unconfirmed", 0.45, 0.85],
      "circle-stroke-color": "#ffffff",
      "circle-stroke-width": 1
    }
  });

  async function refresh() {
    const response = await fetch(apiBaseUrl + "/v1/hotspots");
    if (!response.ok) throw new Error("Unable to refresh river hotspot data");
    map.getSource("river-hotspots").setData(await response.json());
  }

  refresh();
  return { refresh };
}
